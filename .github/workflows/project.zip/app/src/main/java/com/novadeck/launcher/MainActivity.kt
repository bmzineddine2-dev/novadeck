package com.novadeck.launcher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.os.BatteryManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Launcher() } }
    }
}

class Game(val pkg: String, val label: String, val icon: ImageBitmap, val c1: Color, val c2: Color)

fun loadGames(ctx: Context, all: Boolean): List<Game> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .filter { all || it.activityInfo.applicationInfo.category == ApplicationInfo.CATEGORY_GAME }
        .distinctBy { it.activityInfo.packageName }
        .sortedBy { it.loadLabel(pm).toString().lowercase() }
        .map {
            val bmp = it.loadIcon(pm).toBitmap(160, 160)
            val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(px, hsv)
            val sat = hsv[1].coerceIn(0.5f, 0.95f)
            Game(
                it.activityInfo.packageName,
                it.loadLabel(pm).toString(),
                bmp.asImageBitmap(),
                Color.hsv(hsv[0], sat, 0.95f),
                Color.hsv(hsv[0], sat, 0.28f)
            )
        }
}

fun launchGame(ctx: Context, g: Game) {
    val i = ctx.packageManager.getLaunchIntentForPackage(g.pkg)
    if (i != null) ctx.startActivity(i)
    else Toast.makeText(ctx, "Can't open " + g.label, Toast.LENGTH_SHORT).show()
}

fun Modifier.glass(r: Int = 24): Modifier {
    val s = RoundedCornerShape(r.dp)
    return this.clip(s)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.05f))))
        .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.6f), Color.White.copy(alpha = 0.08f))), s)
}

@Composable
fun Launcher() {
    val ctx = LocalContext.current
    var all by remember { mutableStateOf(false) }
    var games by remember { mutableStateOf(emptyList<Game>()) }
    var sel by remember { mutableIntStateOf(0) }
    LaunchedEffect(all) {
        games = withContext(Dispatchers.Default) { loadGames(ctx, all) }
        sel = 0
    }
    BackHandler { }
    val g = games.getOrNull(sel)
    val c1 by animateColorAsState(g?.c1 ?: Color(0xFF3DA8FF), tween(700), label = "c1")
    val c2 by animateColorAsState(g?.c2 ?: Color(0xFF1B2A6B), tween(700), label = "c2")
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(listOf(c2, Color(0xFF05070B))))
            .drawBehind {
                val ctr = Offset(size.width * 0.15f, 0f)
                drawCircle(
                    Brush.radialGradient(listOf(c1.copy(alpha = 0.55f), Color.Transparent), center = ctr, radius = size.width * 0.7f),
                    radius = size.width * 0.7f,
                    center = ctr
                )
            }
    ) {
        Row(
            Modifier.fillMaxSize().systemBarsPadding().padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Sidebar(
                Modifier.weight(0.32f).fillMaxHeight(), games, sel, all,
                { all = it }, { sel = it }, { launchGame(ctx, it) }
            )
            Hero(Modifier.weight(0.68f).fillMaxHeight(), g, c1, c2) { launchGame(ctx, it) }
        }
    }
}

@Composable
fun Chip(t: String, on: Boolean, click: () -> Unit) {
    Text(
        t,
        color = if (on) Color(0xFF0E1C08) else Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (on) Color(0xFFBFF25A) else Color.White.copy(alpha = 0.15f))
            .clickable(onClick = click)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    )
}

@Composable
fun Sidebar(
    m: Modifier, games: List<Game>, sel: Int, all: Boolean,
    onAll: (Boolean) -> Unit, onSel: (Int) -> Unit, onLaunch: (Game) -> Unit
) {
    Column(m.glass(26).padding(8.dp)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Games", !all) { onAll(false) }
            Chip("All apps", all) { onAll(true) }
        }
        Spacer(Modifier.height(6.dp))
        if (games.isEmpty()) {
            Text(
                "No games found.\nTap All apps.",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 13.sp,
                modifier = Modifier.padding(12.dp)
            )
        }
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(games) { i, g ->
                val on = i == sel
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .then(
                            if (on) Modifier.background(
                                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.32f), Color.White.copy(alpha = 0.1f)))
                            ) else Modifier
                        )
                        .clickable { if (on) onLaunch(g) else onSel(i) }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(g.icon, null, Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)))
                    Spacer(Modifier.width(12.dp))
                    Text(g.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun Hero(m: Modifier, g: Game?, c1: Color, c2: Color, onLaunch: (Game) -> Unit) {
    val ctx = LocalContext.current
    val info by produceState(Pair("", -1)) {
        while (true) {
            val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            value = Pair(t, if (lv >= 0 && sc > 0) lv * 100 / sc else -1)
            delay(10_000)
        }
    }
    val shape = RoundedCornerShape(30.dp)
    Box(
        m.clip(shape)
            .background(Brush.linearGradient(listOf(c1, c2)))
            .drawBehind {
                drawCircle(Color.White.copy(alpha = 0.08f), size.height * 0.7f, Offset(size.width * 0.8f, size.height * 0.2f))
                drawCircle(Color.White.copy(alpha = 0.22f), size.height * 0.38f, Offset(size.width * 0.78f, size.height * 0.5f), style = Stroke(6f))
                drawCircle(Color.White.copy(alpha = 0.12f), size.height * 0.2f, Offset(size.width * 0.5f, size.height * 0.15f), style = Stroke(4f))
            }
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.6f), Color.White.copy(alpha = 0.1f))), shape)
    ) {
        Crossfade(g, animationSpec = tween(500), label = "hero") { gg ->
            if (gg != null) {
                Box(Modifier.fillMaxSize()) {
                    Image(
                        gg.icon, null,
                        Modifier.align(Alignment.CenterEnd).padding(end = 40.dp).size(150.dp).clip(RoundedCornerShape(34.dp))
                    )
                    Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
                        Text(gg.label, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Spacer(Modifier.height(14.dp))
                        Text(
                            "Play",
                            color = Color(0xFF0E1C08),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.75f), Color(0xFFBFF25A))))
                                .clickable { onLaunch(gg) }
                                .padding(horizontal = 40.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }
        Row(Modifier.align(Alignment.TopEnd).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (info.second >= 0) {
                Text(
                    info.second.toString() + "%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    modifier = Modifier.glass(16).padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
            Text(
                info.first, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.glass(16).padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
    }
}
