package com.novadeck.launcher

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.SoundEffectConstants
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class MainActivity : ComponentActivity() {
    private val resumed = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 28) {
            val a = window.attributes
            a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = a
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Launcher(resumed.intValue) { applyImmersive(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumed.intValue++
    }

    private fun applyImmersive(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive(getSharedPreferences("nd", MODE_PRIVATE).getBoolean("immersive", true))
    }
}

class App(val pkg: String, val label: String, val icon: ImageBitmap, val c1: Color, val c2: Color, val isGame: Boolean)

private val cache = ConcurrentHashMap<String, App>()

@Suppress("DEPRECATION")
fun loadApps(ctx: Context): List<App> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val pkg = ri.activityInfo.packageName
            cache.getOrPut(pkg) {
                val bmp = ri.loadIcon(pm).toBitmap(256, 256)
                val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
                val hsv = FloatArray(3)
                android.graphics.Color.colorToHSV(px, hsv)
                val sat = hsv[1].coerceIn(0.5f, 0.95f)
                val ai = ri.activityInfo.applicationInfo
                App(
                    pkg, ri.loadLabel(pm).toString(), bmp.asImageBitmap(),
                    Color.hsv(hsv[0], sat, 0.95f), Color.hsv(hsv[0], sat, 0.28f),
                    ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                )
            }
        }
}

@Suppress("DEPRECATION")
fun hasUsage(ctx: Context): Boolean {
    return try {
        val ao = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }
}

fun loadUsage(ctx: Context): Map<String, Long> {
    if (!hasUsage(ctx)) return emptyMap()
    return try {
        val um = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        um.queryAndAggregateUsageStats(now - 30L * 86400000L, now).mapValues { it.value.totalTimeInForeground }
    } catch (e: Exception) { emptyMap() }
}

fun coverFile(ctx: Context, pkg: String) = File(ctx.filesDir, "cover_$pkg.jpg")

fun loadCovers(ctx: Context, apps: List<App>): Map<String, ImageBitmap> {
    val out = HashMap<String, ImageBitmap>()
    for (a in apps) {
        val f = coverFile(ctx, a.pkg)
        if (!f.exists()) continue
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var s = 1
            while (o.outWidth / (s * 2) >= 1400) s *= 2
            val b = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
            if (b != null) out[a.pkg] = b.asImageBitmap()
        } catch (e: Exception) { }
    }
    return out
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nd", Context.MODE_PRIVATE)
    var favs by mutableStateOf(sp.getStringSet("favs", emptySet())!!.toSet())
    var tagged by mutableStateOf(sp.getStringSet("tagged", emptySet())!!.toSet())
    var untagged by mutableStateOf(sp.getStringSet("untagged", emptySet())!!.toSet())
    var hidden by mutableStateOf(sp.getStringSet("hidden", emptySet())!!.toSet())
    var sortRecent by mutableStateOf(sp.getBoolean("sortRecent", false))
    var haptics by mutableStateOf(sp.getBoolean("haptics", true))
    var lite by mutableStateOf(sp.getBoolean("lite", false))
    var immersive by mutableStateOf(sp.getBoolean("immersive", true))
    var hints by mutableStateOf(sp.getBoolean("hints", true))
    var uiSound by mutableStateOf(sp.getBoolean("uiSound", true))
    var tab by mutableIntStateOf(sp.getInt("tab", 0))
    var sel by mutableStateOf<String?>(sp.getString("sel", null))
    var stamp by mutableIntStateOf(0)

    fun flip(key: String, pkg: String) {
        val cur = when (key) { "favs" -> favs; "tagged" -> tagged; "untagged" -> untagged; else -> hidden }
        val n = if (pkg in cur) cur - pkg else cur + pkg
        when (key) { "favs" -> favs = n; "tagged" -> tagged = n; "untagged" -> untagged = n; else -> hidden = n }
        sp.edit().putStringSet(key, n).apply()
    }
    fun inGames(a: App) = a.pkg !in untagged && (a.isGame || a.pkg in tagged)
    fun setGame(a: App, on: Boolean) {
        if (on) {
            if (a.pkg in untagged) flip("untagged", a.pkg)
            if (!a.isGame && a.pkg !in tagged) flip("tagged", a.pkg)
        } else {
            if (a.pkg in tagged) flip("tagged", a.pkg)
            if (a.isGame && a.pkg !in untagged) flip("untagged", a.pkg)
        }
    }
    fun clearHidden() { hidden = emptySet(); sp.edit().putStringSet("hidden", emptySet()).apply() }
    fun set(k: String, v: Boolean) {
        when (k) {
            "sortRecent" -> sortRecent = v
            "haptics" -> haptics = v
            "immersive" -> immersive = v
            "hints" -> hints = v
            "uiSound" -> uiSound = v
            else -> lite = v
        }
        sp.edit().putBoolean(k, v).apply()
    }
    fun saveTab(v: Int) { tab = v; sp.edit().putInt("tab", v).apply() }
    fun saveSel(pkg: String) { sel = pkg; sp.edit().putString("sel", pkg).apply() }
    fun last(pkg: String) = sp.getLong("last_$pkg", 0L)
    fun count(pkg: String) = sp.getInt("cnt_$pkg", 0)
    fun played(pkg: String) {
        sp.edit().putLong("last_$pkg", System.currentTimeMillis()).putInt("cnt_$pkg", count(pkg) + 1).apply()
        stamp++
    }
}

fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "just now"
        m < 60 -> "$m min ago"
        m < 1440 -> "${m / 60} h ago"
        else -> "${m / 1440} d ago"
    }
}

fun dur(ms: Long): String {
    val m = ms / 60000
    return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
}

fun launchApp(ctx: Context, p: Prefs, a: App) {
    val i = ctx.packageManager.getLaunchIntentForPackage(a.pkg)
    if (i != null) {
        p.played(a.pkg)
        try { ctx.startActivity(i) } catch (e: Exception) { Toast.makeText(ctx, "Can't open " + a.label, Toast.LENGTH_SHORT).show() }
    } else Toast.makeText(ctx, "Can't open " + a.label, Toast.LENGTH_SHORT).show()
}

fun Modifier.glass(r: Int = 24): Modifier {
    val s = RoundedCornerShape(r.dp)
    return this.clip(s)
        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.05f))))
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.22f), Color.Transparent), endY = size.height * 0.45f))
        }
        .border(
            1.dp,
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.65f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.25f))),
            s
        )
}

@Composable
fun Intro() {
    val rot by rememberInfiniteTransition(label = "r").animateFloat(0f, 360f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "rot")
    val sc = remember { Animatable(0.3f) }
    LaunchedEffect(Unit) { sc.animateTo(1f, tween(1100)) }
    Box(
        Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF10301A), Color(0xFF030504)))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(26.dp)) {
            Box(
                Modifier.size(110.dp).drawBehind {
                    val s = sc.value
                    rotate(rot) {
                        drawArc(
                            brush = Brush.sweepGradient(listOf(Color.Transparent, Color(0xFFBFF25A), Color.White)),
                            startAngle = 0f, sweepAngle = 300f, useCenter = false,
                            topLeft = Offset(size.width * (1 - s) / 2, size.height * (1 - s) / 2),
                            size = Size(size.width * s, size.height * s),
                            style = Stroke(width = 10f, cap = StrokeCap.Round)
                        )
                    }
                }
            )
            Text("NOVADECK", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Light, letterSpacing = 8.sp)
        }
    }
}

@Composable
fun Launcher(resume: Int, onImmersive: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val p = remember { Prefs(ctx) }
    var apps by remember { mutableStateOf(emptyList<App>()) }
    var usage by remember { mutableStateOf(emptyMap<String, Long>()) }
    var usageOn by remember { mutableStateOf(false) }
    var covers by remember { mutableStateOf(emptyMap<String, ImageBitmap>()) }
    var coverTick by remember { mutableIntStateOf(0) }
    var coverFor by remember { mutableStateOf<String?>(null) }
    var settings by remember { mutableStateOf(false) }
    var intro by remember { mutableStateOf(true) }
    val fr = remember { FocusRequester() }

    LaunchedEffect(resume) {
        apps = withContext(Dispatchers.Default) { loadApps(ctx) }
        usageOn = hasUsage(ctx)
        usage = withContext(Dispatchers.Default) { loadUsage(ctx) }
    }
    LaunchedEffect(apps, coverTick) { covers = withContext(Dispatchers.Default) { loadCovers(ctx, apps) } }
    LaunchedEffect(Unit) {
        delay(1800)
        intro = false
        try { fr.requestFocus() } catch (e: Exception) { }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        val pkg = coverFor
        if (uri != null && pkg != null) {
            try {
                ctx.contentResolver.openInputStream(uri)?.use { i -> coverFile(ctx, pkg).outputStream().use { o -> i.copyTo(o) } }
                coverTick++
            } catch (e: Exception) {
                Toast.makeText(ctx, "Couldn't load that image", Toast.LENGTH_SHORT).show()
            }
        }
    }
    BackHandler { settings = false }

    val vis = remember(apps, p.tab, p.sortRecent, p.favs, p.tagged, p.untagged, p.hidden, p.stamp) {
        apps.filter { it.pkg !in p.hidden }
            .filter { when (p.tab) { 0 -> p.inGames(it); 1 -> it.pkg in p.favs; else -> true } }
            .let { l ->
                if (p.sortRecent) l.sortedWith(compareByDescending<App> { p.last(it.pkg) }.thenBy { it.label.lowercase() })
                else l.sortedBy { it.label.lowercase() }
            }
    }
    val g = vis.firstOrNull { it.pkg == p.sel } ?: vis.firstOrNull()
    val c1 by animateColorAsState(g?.c1 ?: Color(0xFF3DA8FF), tween(700), label = "c1")
    val c2 by animateColorAsState(g?.c2 ?: Color(0xFF1B2A6B), tween(700), label = "c2")
    val inf = rememberInfiniteTransition(label = "bg")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "t")

    val feedback: () -> Unit = {
        if (p.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (p.uiSound) view.playSoundEffect(SoundEffectConstants.CLICK)
    }
    val step: (Int) -> Unit = { d ->
        if (vis.isNotEmpty()) {
            val i = vis.indexOfFirst { it.pkg == g?.pkg }.coerceAtLeast(0)
            val n = (i + d).coerceIn(0, vis.size - 1)
            if (n != i) { feedback(); p.saveSel(vis[n].pkg) }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(listOf(c2, Color(0xFF05070B))))
            .drawBehind {
                val ctr = Offset(size.width * 0.15f, 0f)
                drawCircle(
                    Brush.radialGradient(listOf(c1.copy(alpha = 0.55f), Color.Transparent), center = ctr, radius = size.width * 0.7f),
                    radius = size.width * 0.7f, center = ctr
                )
                if (!p.lite) {
                    val w = size.width
                    val h = size.height
                    drawCircle(Color.White.copy(alpha = 0.07f), 90f, Offset(w * 0.30f, h * (0.75f - 0.08f * t)))
                    drawCircle(Color.White.copy(alpha = 0.06f), 50f, Offset(w * 0.55f, h * (0.20f + 0.10f * t)))
                    drawCircle(Color.White.copy(alpha = 0.05f), 130f, Offset(w * 0.90f, h * (0.85f - 0.06f * t)))
                }
            }
            .onPreviewKeyEvent { e ->
                if (settings || intro || e.type != KeyEventType.KeyDown) false
                else when (e.key) {
                    Key.DirectionDown, Key.DirectionRight -> { step(1); true }
                    Key.DirectionUp, Key.DirectionLeft -> { step(-1); true }
                    Key.Enter, Key.NumPadEnter, Key.ButtonA, Key.DirectionCenter -> { g?.let { launchApp(ctx, p, it) }; true }
                    Key.ButtonY -> { g?.let { p.flip("favs", it.pkg) }; true }
                    Key.ButtonX, Key.Menu -> { settings = true; true }
                    Key.ButtonR1 -> { p.saveTab((p.tab + 1) % 3); true }
                    Key.ButtonL1 -> { p.saveTab((p.tab + 2) % 3); true }
                    else -> false
                }
            }
            .focusRequester(fr)
            .focusable()
    ) {
        if (!p.lite && Build.VERSION.SDK_INT >= 31) {
            Crossfade(g, animationSpec = tween(600), label = "art") { gg ->
                if (gg != null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Image(gg.icon, null, Modifier.size(560.dp).blur(90.dp).alpha(0.4f))
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxSize().safeDrawingPadding().padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Sidebar(
                Modifier.weight(0.32f).fillMaxHeight(), vis, g, p, usage, covers,
                { feedback(); p.saveSel(it.pkg) },
                { launchApp(ctx, p, it) },
                { coverFor = it.pkg; picker.launch("image/*") },
                { coverFile(ctx, it.pkg).delete(); coverTick++ },
                { settings = true }
            )
            Hero(Modifier.weight(0.68f).fillMaxHeight(), g, c1, c2, p, covers, usage, step) { launchApp(ctx, p, it) }
        }
        if (settings) SettingsPanel(p, usageOn, onImmersive) { settings = false }
        AnimatedVisibility(visible = intro, exit = fadeOut(tween(600))) { Intro() }
    }
}

@Composable
fun Chip(t: String, on: Boolean, click: () -> Unit) {
    val bg by animateColorAsState(if (on) Color(0xFFBFF25A) else Color.White.copy(alpha = 0.15f), tween(250), label = "chip")
    Text(
        t,
        color = if (on) Color(0xFF0E1C08) else Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(CircleShape).background(bg).clickable(onClick = click).padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun Tag(t: String) {
    Text(t, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, modifier = Modifier.glass(14).padding(horizontal = 10.dp, vertical = 4.dp))
}

@Composable
fun MenuItem(t: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(t) }, onClick = onClick)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Sidebar(
    m: Modifier, vis: List<App>, cur: App?, p: Prefs, usage: Map<String, Long>, covers: Map<String, ImageBitmap>,
    onSel: (App) -> Unit, onLaunch: (App) -> Unit, onCover: (App) -> Unit, onClearCover: (App) -> Unit, onSettings: () -> Unit
) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf<String?>(null) }
    Column(m.glass(26).padding(8.dp)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("Games", p.tab == 0) { p.saveTab(0) }
            Chip("Favorites", p.tab == 1) { p.saveTab(1) }
            Chip("All", p.tab == 2) { p.saveTab(2) }
        }
        Spacer(Modifier.height(6.dp))
        if (vis.isEmpty()) {
            Text(
                when (p.tab) {
                    0 -> "No games detected.\nOpen All, long-press an app and choose Add to Games."
                    1 -> "No favorites yet.\nLong-press an app to add one."
                    else -> "No apps found."
                },
                color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(12.dp)
            )
        }
        LazyColumn(Modifier.weight(1f)) {
            items(vis, key = { it.pkg }) { a ->
                val on = a.pkg == cur?.pkg
                val sc by animateFloatAsState(if (on) 1.12f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "ic")
                val u = usage[a.pkg] ?: 0L
                Box {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .then(
                                if (on) Modifier.background(
                                    Brush.linearGradient(listOf(Color.White.copy(alpha = 0.32f), Color.White.copy(alpha = 0.1f)))
                                ) else Modifier
                            )
                            .combinedClickable(
                                onClick = { if (on) onLaunch(a) else onSel(a) },
                                onLongClick = { menu = a.pkg }
                            )
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            a.icon, null,
                            Modifier.size(44.dp).graphicsLayer { scaleX = sc; scaleY = sc }.clip(RoundedCornerShape(13.dp))
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(
                                if (u > 0) dur(u) else if (a.pkg in covers) "Custom cover" else if (p.inGames(a)) "Game" else "App",
                                color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp, maxLines = 1
                            )
                        }
                        if (a.pkg in p.favs) Text("★", color = Color(0xFFBFF25A), fontSize = 14.sp)
                    }
                    DropdownMenu(expanded = menu == a.pkg, onDismissRequest = { menu = null }) {
                        MenuItem(if (a.pkg in p.favs) "Remove from favorites" else "Add to favorites") { p.flip("favs", a.pkg); menu = null }
                        MenuItem(if (p.inGames(a)) "Remove from Games" else "Add to Games") { p.setGame(a, !p.inGames(a)); menu = null }
                        MenuItem("Set cover image") { menu = null; onCover(a) }
                        if (a.pkg in covers) MenuItem("Remove cover image") { menu = null; onClearCover(a) }
                        MenuItem("Hide") { p.flip("hidden", a.pkg); menu = null }
                        MenuItem("App info") {
                            menu = null
                            try {
                                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", a.pkg, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Exception) { }
                        }
                        MenuItem("Uninstall") {
                            menu = null
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.fromParts("package", a.pkg, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Exception) { }
                        }
                    }
                }
            }
        }
        Text(
            "Settings", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).glass(18).clickable(onClick = onSettings).padding(12.dp)
        )
    }
}

@Composable
fun Hero(
    m: Modifier, g: App?, c1: Color, c2: Color, p: Prefs, covers: Map<String, ImageBitmap>, usage: Map<String, Long>,
    onStep: (Int) -> Unit, onLaunch: (App) -> Unit
) {
    val ctx = LocalContext.current
    val info by produceState(Pair("", -1)) {
        while (true) {
            val tm = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            value = Pair(tm, if (lv >= 0 && sc > 0) lv * 100 / sc else -1)
            delay(10_000)
        }
    }
    val inf = rememberInfiniteTransition(label = "h")
    val bob by inf.animateFloat(-6f, 6f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val stepS = rememberUpdatedState(onStep)
    val shape = RoundedCornerShape(30.dp)
    Box(
        m.clip(shape)
            .background(Brush.linearGradient(listOf(c1, c2)))
            .drawBehind {
                drawCircle(Color.White.copy(alpha = 0.08f), size.height * 0.7f, Offset(size.width * 0.8f, size.height * 0.2f))
                drawCircle(Color.White.copy(alpha = 0.22f), size.height * 0.38f, Offset(size.width * 0.78f, size.height * 0.5f), style = Stroke(6f))
                drawCircle(Color.White.copy(alpha = 0.12f), size.height * 0.2f, Offset(size.width * 0.5f, size.height * 0.15f), style = Stroke(4f))
            }
            .pointerInput(Unit) {
                var dx = 0f
                detectHorizontalDragGestures(
                    onDragStart = { dx = 0f },
                    onDragEnd = { if (dx < -90f) stepS.value(1) else if (dx > 90f) stepS.value(-1) },
                    onHorizontalDrag = { _, d -> dx += d }
                )
            }
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.6f), Color.White.copy(alpha = 0.1f))), shape)
    ) {
        Crossfade(g, animationSpec = tween(500), label = "hero") { gg ->
            if (gg != null) {
                Box(Modifier.fillMaxSize()) {
                    val cv = covers[gg.pkg]
                    if (cv != null) {
                        Image(cv, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)))))
                    } else {
                        val sc = remember { Animatable(0.85f) }
                        LaunchedEffect(Unit) { sc.animateTo(1f, spring(Spring.DampingRatioMediumBouncy)) }
                        Image(
                            gg.icon, null,
                            Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 40.dp)
                                .size(150.dp)
                                .graphicsLayer { scaleX = sc.value; scaleY = sc.value; translationY = bob }
                                .clip(RoundedCornerShape(34.dp))
                                .border(1.5.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(34.dp))
                        )
                    }
                    Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
                        Text(gg.label, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, letterSpacing = (-0.5).sp)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Tag(if (gg.isGame) "Game" else "App")
                            val u = usage[gg.pkg] ?: 0L
                            if (u > 0) Tag(dur(u) + " this month")
                            val lp = p.last(gg.pkg)
                            Tag(if (lp == 0L) "Not played yet" else "Played " + ago(lp))
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                "Play",
                                color = Color(0xFF0E1C08),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.75f), Color(0xFFBFF25A))))
                                    .clickable { onLaunch(gg) }
                                    .padding(horizontal = 40.dp, vertical = 12.dp)
                            )
                            Text(
                                if (gg.pkg in p.favs) "★" else "☆", color = Color.White, fontSize = 22.sp,
                                modifier = Modifier.size(46.dp).glass(23).clickable { p.flip("favs", gg.pkg) }.wrapContentSize(Alignment.Center)
                            )
                        }
                    }
                }
            }
        }
        if (p.hints) {
            Row(Modifier.align(Alignment.BottomEnd).padding(14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Tag("A  Play")
                Tag("Y  Favorite")
                Tag("X  Settings")
                Tag("LB RB  Tabs")
            }
        }
        Row(Modifier.align(Alignment.TopEnd).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (info.second >= 0) {
                Text(
                    info.second.toString() + "%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    modifier = Modifier.glass(16).padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
            Text(
                info.first, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.glass(16).padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun SwitchRow(label: String, v: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = change)
    }
}

@Composable
fun SettingsPanel(p: Prefs, usageOn: Boolean, onImmersive: (Boolean) -> Unit, close: () -> Unit) {
    val ctx = LocalContext.current
    val none = remember { MutableInteractionSource() }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).clickable(interactionSource = none, indication = null, onClick = close)) {
        Column(
            Modifier
                .align(Alignment.CenterEnd)
                .safeDrawingPadding()
                .padding(12.dp)
                .width(340.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xE60F141B))
                .glass(26)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            SwitchRow("Fullscreen (hide system buttons)", p.immersive) { p.set("immersive", it); onImmersive(it) }
            SwitchRow("Controller hints", p.hints) { p.set("hints", it) }
            SwitchRow("UI sounds", p.uiSound) { p.set("uiSound", it) }
            SwitchRow("Haptic feedback", p.haptics) { p.set("haptics", it) }
            SwitchRow("Sort by recently played", p.sortRecent) { p.set("sortRecent", it) }
            SwitchRow("Lite mode (fewer effects)", p.lite) { p.set("lite", it) }
            Text(
                if (usageOn) "Play time tracking: on (last 30 days)" else "Turn on play time tracking (opens Usage access)",
                color = Color(0xFFBFF25A), fontSize = 14.sp,
                modifier = Modifier.clickable {
                    try { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                }.padding(vertical = 8.dp)
            )
            Text(
                "Unhide all apps (" + p.hidden.size + " hidden)", color = Color(0xFFBFF25A), fontSize = 14.sp,
                modifier = Modifier.clickable { p.clearHidden() }.padding(vertical = 8.dp)
            )
            Text("NovaDeck 1.2. Long-press any app for more options.", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }
    }
}
